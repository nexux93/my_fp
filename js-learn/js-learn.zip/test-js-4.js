// задание 1


function alphaFun() {
    var alphaString = prompt('Число от 1 до 999'); // string value
    var alphaArr = alphaString.split(''); // transform in the array
    var aplhaObj = {};

    if (alphaArr.length == 1) {
        aplhaObj.one = +alphaArr[0];

    } else if (alphaArr.length == 2) {
        aplhaObj.tens = +alphaArr[0];
        aplhaObj.one = +alphaArr[1];

    } else if (alphaArr.length == 3) {
        aplhaObj.hundreds = +alphaArr[0];
        aplhaObj.tens = +alphaArr[1];
        aplhaObj.one = +alphaArr[2];
    }

    if (alphaArr.length > 3) { // we are check array length
        delete aplhaObj.hundreds;
        delete aplhaObj.tens;
        delete aplhaObj.one;
        console.error('Не верное значение');
        console.log(aplhaObj);

    } else if (alphaArr.length <= 3) {

        console.log(aplhaObj);

    }


}

alphaFun();


// задание 2

// var product = {
//     item: 'dress',
//     count: '2',
//     price: '23'
// };
//
// function priceTotal() {
//     var summ = product.count * product.price;
//     console.log(summ);
//     return summ;
//
// }
//
// priceTotal();
