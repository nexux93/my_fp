// var i = 0;
//
// while (i < 100) {
//     ++i;
//     var b = i++;
//
//     if ((i % b) === 0) {
//         console.log(i);
//     }
//
// }

// var price = [1, 2, 3, 5, 61234, 235, 1241];
//
// function countBasketPrice(price) {
//     var summ = 0;
//     for (var i = 0; i < price.length; i++) {
//         summ += price[i];
//     }
//     console.log(summ);
// }
//
// countBasketPrice(price);


for (i=0; i<9; ++i && console.log(i)) {

}
